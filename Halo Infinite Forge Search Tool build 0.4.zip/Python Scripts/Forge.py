from colorama import * 
from Forge_Menu_Items import *

init(convert=True)

print("                                                                                                                                                             Made by Quinn Barron")


print("\nThis program prompts you for an item to search for.")
print("It will then return to you, in alphabetical order and numbered accordigly, every item in the Halo Infinite Forge Menu")
print("The program will print out every item relevant to your search in a colour coded sequence")
print(f"\nIt starts with {Fore.GREEN}CATEGORIES {Style.RESET_ALL}that will be printed in {Fore.GREEN}Green{Style.RESET_ALL}")
print(f"It then prints the {Fore.YELLOW}SUBCATEGORIES{Style.RESET_ALL} in{Fore.YELLOW} Yellow {Style.RESET_ALL}")
print(f"It then print out the {Fore.RED}ITEMS{Style.RESET_ALL} in {Fore.RED}Red{Style.RESET_ALL}")


count = 0

def search_forge_menu(keyword):
    global count
    count = 0
    results = []
    for category, items in ForgeMenu.items():
        for subcategory, subitems in items.items():
            for item in subitems:
                if keyword.lower() in item.lower():
                    results.append((item, subcategory, category))
                    count += 1
    results.sort()
    for i, result in enumerate(results):
        print(f"\n{i+1}. {Fore.GREEN}{result[2]}{Style.RESET_ALL} {Fore.YELLOW}{result[1]}{Style.RESET_ALL} {Fore.RED}{result[0]}{Style.RESET_ALL}")
        # print(f"\n{result[0]} is in the {result[1]} subcategory under the {result[2]} category")


def main():
    global count
    answer = "y"

    while answer == "y": 
        searchItem = input("\nWhat Item would you like to search for?:")
        result = search_forge_menu(searchItem)
        print(f"\n{Fore.LIGHTMAGENTA_EX}{count} RESULTS{Style.RESET_ALL}")

        answer = input(f"\nWould you like to search Again?{Fore.RED}(Y/N){Style.RESET_ALL}: ")

        if answer == "Y" or answer == "y" or answer == "Yes" or answer == "yes": 
            main()
        else: 
            raise SystemExit


    
main()






